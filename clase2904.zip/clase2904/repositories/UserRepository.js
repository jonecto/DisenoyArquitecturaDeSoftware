let userList = [];
class UserRepository {
    
    findAll(){
        return userList;
    }

    findById(id){
        return userList.find(user=>user.id===id);
    }

    save(user){
        users.push(user);
        return user;
    }

    update(id, updateUser){
        users=users.map(user=>(user.id===id ? updateUser:user)); // ? -> if <left> then <right>
        return updateUser;
    }

    delete(id){
        users=users.filter(user=>user.id===id);
    }
}
module.exports=UserRepository