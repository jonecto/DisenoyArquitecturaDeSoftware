import express, { urlencoded } from 'express';
import { join, resolve } from "path";

import appRouter from "./routes/router.js";
const userRoutes = require('./routes/userRoutes.js')

const app = express();
app.use(express,urlencoded({extended:true})); // esto es lo mismo de app.use(express.static(join("./public")))

const port = 2303;
app.set("view engine", 'ejs');
app.set("views", "views");
app.use(express.static(join("./public")));
	
app.use("/", appRouter);
app.use("/users", appRouter);

app.listen(port, () => {
  console.log(`Server running 🚀 at http://localhost:${port}`);
});