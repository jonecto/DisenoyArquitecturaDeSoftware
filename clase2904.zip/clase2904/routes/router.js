import { Router } from "express";
    const router = Router();
    router.get('/', (request, response) => {
        response.render('index', {
            message: 'Amoooooooooooor'
        })     	
    })
    router.get('/amor', (request, response) => {
        response.render('layout', {
            message: 'te amo'
        })     	
    })
    
    export default router;    
    